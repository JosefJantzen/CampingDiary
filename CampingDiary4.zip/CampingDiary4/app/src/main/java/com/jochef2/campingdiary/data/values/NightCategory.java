package com.jochef2.campingdiary.data.values;

public enum NightCategory {
    CAMPSITE,
    MOTORHOME_AREA,
    PARKING_AREA,
    RESTING_SPOT,
    NATURE,
    FARM,
    OFF_ROAD,
    OTHER
}
