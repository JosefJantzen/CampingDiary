package com.jochef2.campingdiary.ui.nights;

import androidx.lifecycle.ViewModel;

public class NightsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}