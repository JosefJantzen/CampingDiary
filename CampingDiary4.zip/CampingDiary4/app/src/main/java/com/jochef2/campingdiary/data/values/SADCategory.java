package com.jochef2.campingdiary.data.values;

public enum SADCategory {
    WATER,
    GREY_WATER,
    TOILETTE,
    GARBAGE,
    GAS
}
